/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laptrinhjavagd;

/**
 *
 * @author Le Anh Tuan Dung
 */
public class CongViec {
    private String MACV;
    private String MADT;
    private String TGBD;
    private String TGKT;
    private double Luong;
    private String DiaDiem;
    private String MoTa;
    private String NganhNghe;
    private String LoaiCV;
    private int SLTuyen;

    public CongViec() {
    }

    public CongViec(String MACV, String MADT, String TGBD, String TGKT, double Luong, String DiaDiem, String MoTa, String NganhNghe, String LoaiCV, int SLTuyen) {
        this.MACV = MACV;
        this.MADT = MADT;
        this.TGBD = TGBD;
        this.TGKT = TGKT;
        this.Luong = Luong;
        this.DiaDiem = DiaDiem;
        this.MoTa = MoTa;
        this.NganhNghe = NganhNghe;
        this.LoaiCV = LoaiCV;
        this.SLTuyen = SLTuyen;
    }

    public String getMACV() {
        return MACV;
    }

    public void setMACV(String MACV) {
        this.MACV = MACV;
    }

    public String getMADT() {
        return MADT;
    }

    public void setMADT(String MADT) {
        this.MADT = MADT;
    }

    public String getTGBD() {
        return TGBD;
    }

    public void setTGBD(String TGBD) {
        this.TGBD = TGBD;
    }

    public String getTGKT() {
        return TGKT;
    }

    public void setTGKT(String TGKT) {
        this.TGKT = TGKT;
    }

    public double getLuong() {
        return Luong;
    }

    public void setLuong(double Luong) {
        this.Luong = Luong;
    }

    public String getDiaDiem() {
        return DiaDiem;
    }

    public void setDiaDiem(String DiaDiem) {
        this.DiaDiem = DiaDiem;
    }

    public String getMoTa() {
        return MoTa;
    }

    public void setMoTa(String MoTa) {
        this.MoTa = MoTa;
    }

    public String getNganhNghe() {
        return NganhNghe;
    }

    public void setNganhNghe(String NganhNghe) {
        this.NganhNghe = NganhNghe;
    }

    public String getLoaiCV() {
        return LoaiCV;
    }

    public void setLoaiCV(String LoaiCV) {
        this.LoaiCV = LoaiCV;
    }

    public int getSLTuyen() {
        return SLTuyen;
    }

    public void setSLTuyen(int SLTuyen) {
        this.SLTuyen = SLTuyen;
    }
    
}
