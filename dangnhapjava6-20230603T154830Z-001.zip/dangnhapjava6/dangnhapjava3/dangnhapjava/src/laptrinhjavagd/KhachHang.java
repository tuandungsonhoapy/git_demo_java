package laptrinhjavagd;

public class KhachHang {
	private String MAKH;
	private String TENKH;
	private String GIOITINH;
	private String NGAYSINH;
	private String CMND;
	private String SDT;
	public String getMAKH() {
		return MAKH;
	}
	public void setMAKH(String mAKH) {
		MAKH = mAKH;
	}
	public String getTENKH() {
		return TENKH;
	}
	public void setTENKH(String tENKH) {
		TENKH = tENKH;
	}
	public String getGIOITINH() {
		return GIOITINH;
	}
	public void setGIOITINH(String gIOITINH) {
		GIOITINH = gIOITINH;
	}
	public String getNGAYSINH() {
		return NGAYSINH;
	}
	public void setNGAYSINH(String nGAYSINH) {
		NGAYSINH = nGAYSINH;
	}
	public String getCMND() {
		return CMND;
	}
	public void setCMND(String cMND) {
		CMND = cMND;
	}
	public String getSDT() {
		return SDT;
	}
	public void setSDT(String sDT) {
		SDT = sDT;
	}
	public KhachHang(String mAKH, String tENKH, String gIOITINH, String nGAYSINH, String cMND, String sDT) {
		super();
		MAKH = mAKH;
		TENKH = tENKH;
		GIOITINH = gIOITINH;
		NGAYSINH = nGAYSINH;
		CMND = cMND;
		SDT = sDT;
	}
	public KhachHang() {
		super();
		MAKH = "";
		TENKH = "";
		GIOITINH = "";
		NGAYSINH = "";
		CMND = "";
		SDT = "";
	}
	
}
