/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package laptrinhjavagd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import static java.time.temporal.TemporalQueries.localDate;
import java.util.Date;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author dosid
 */
public class QLCV extends javax.swing.JPanel {

    /**
     * Creates new form QLKH
     */ 
    private TaoKetNoiCSDL connec_ketnoi = new TaoKetNoiCSDL();
	private Connection connec = connec_ketnoi.TKNCSDL();
	private ArrayList<CongViec> arls = new ArrayList<>();  
	private int row_n; 
	private DefaultTableModel modeltb;
	private DefaultComboBoxModel<String> modelcomboboxDD = new DefaultComboBoxModel<>();
	private DefaultComboBoxModel<String> modelcomboboxNN = new DefaultComboBoxModel<>();
	private DefaultComboBoxModel<String> modelcomboboxLB = new DefaultComboBoxModel<>();
	private DefaultComboBoxModel<String> modelcomboboxLL = new DefaultComboBoxModel<>();

    private String jcb_text;
	
	public QLCV() throws SQLException {
            initComponents();
            groupLCV();
            border1();
            modeltb = (DefaultTableModel) jTable1.getModel(); 
            loaddulieuvaobang();  
            
        }
	public void groupLCV()
    { 
    	buttonGroup1.add(jCheckBoxFullTime);
    	buttonGroup1.add(jCheckBoxPartTime);
    	buttonGroup1.add(jCheckBoxLuongLien);
    }
        public void loaddulieuvaocomboboxDD() throws SQLException
        {
            String sql = "SELECT DISTINCT(DIADIEM) FROM CONGVIEC";
            Statement stm1 = connec.createStatement();
            ResultSet rss = stm1.executeQuery(sql); 
            while(rss.next())
            	modelcomboboxDD.addElement(rss.getString(1)); 
        }
        public void loaddulieuvaocomboboxNN() throws SQLException
        {
            String sql = "SELECT DISTINCT(NGANHNGHE) FROM CONGVIEC";
            Statement stm1 = connec.createStatement();
            ResultSet rss = stm1.executeQuery(sql);
            while(rss.next())
            	modelcomboboxNN.addElement(rss.getString(1)); 
        }
        public void loaddulieuvaocomboboxLB() throws SQLException
        {  
        	modelcomboboxLB.addElement("0"); 
            	modelcomboboxLB.addElement("3000000"); 
            	modelcomboboxLB.addElement("6000000");
            	modelcomboboxLB.addElement("10000000");
            	modelcomboboxLB.addElement("15000000");
        }
        public void loaddulieuvaocomboboxLL() throws SQLException
        {
        	modelcomboboxLL.addElement("8000000"); 
        	modelcomboboxLL.addElement("15000000");
        	modelcomboboxLL.addElement("25000000");
        	modelcomboboxLL.addElement("50000000");
        }
    public void loaddulieuvaobang()
    {  
        try { 
            PreparedStatement prst =  connec.prepareStatement("SELECT * FROM CONGVIEC");
            ResultSet rs = prst.executeQuery(); 
            Object objList[] = new Object[10];
            while(rs.next())
            {
            	 objList[0] = rs.getString(1); 
            	 objList[1] = rs.getString(2);
    			 objList[2] = rs.getString(3);
				 objList[3] = rs.getString(4);
				 objList[4] = rs.getDouble(5);
				 objList[5] = rs.getString(6);
                 objList[6] = rs.getString(7);
				 objList[7] = rs.getString(8);
				 objList[8] = rs.getString(9);
				 objList[9] = rs.getString(10);
            	modeltb.addRow(objList);
            }
        } 
        catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    
    public void loaddulieuvao_arrlist(ResultSet rs) throws SQLException
    {
    	while(rs.next())
	       {
	    	 CongViec CV = new CongViec();
	    	 CV.setMACV(rs.getString(1));
	    	 CV.setMADT(rs.getString(2));
	    	 CV.setTGBD(rs.getString(3));
	    	 CV.setTGKT(rs.getString(4));
	    	 CV.setLuong(rs.getDouble(5));
	    	 CV.setDiaDiem(rs.getString(6));
             CV.setMoTa(rs.getString(7));
             CV.setNganhNghe(rs.getString(8));
             CV.setLoaiCV(rs.getString(9));
             CV.setSLTuyen(rs.getInt(10));
	    	 arls.add(CV);
	       } 
    }
    
    public void hienthiDLrabang()
    { 
	       Object objList[] = new Object[10]; 
	       modeltb.setRowCount(0);
	       for(CongViec obj: arls)
       	   {
	        	 objList[0] = obj.getMACV();
	        	 objList[1] = obj.getMADT();
				 objList[2] = obj.getTGBD();
				 objList[3] = obj.getTGKT();
				 objList[4] = obj.getLuong();
				 objList[5] = obj.getDiaDiem();
                 objList[6] = obj.getMoTa();
				 objList[7] = obj.getNganhNghe(); 
				 objList[8] = obj.getLoaiCV();
				 //objList[9] = obj.getLuong();
				 objList[9] = obj.getSLTuyen();
	        	 modeltb.addRow(objList);
       	   }
    }
    
    public void border1()
    {  
             jPanel4.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
             jPanel3.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));	
             Timkiem.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
             JCBB_BLHT_DD.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));	
             jTable1.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
             jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
             jLabel1.setForeground(new java.awt.Color(125, 22, 12));
             Them.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 8, 10, 2));
             Them.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
             Them.setForeground(new java.awt.Color(182, 76, 11));
             Xoa.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 8, 10, 2));
             Xoa.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
             Xoa.setForeground(new java.awt.Color(182, 76, 11));
             Sua.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 8, 10, 2)); 
             Sua.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
             Sua.setForeground(new java.awt.Color(182, 76, 11));
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     * @throws SQLException 
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() throws SQLException {
        buttonGroup1 = new javax.swing.ButtonGroup();

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Them = new javax.swing.JButton();
        Sua = new javax.swing.JButton();
        Xoa = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        Timkiem = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        loaddulieuvaocomboboxDD();
        JCBB_BLHT_DD = new javax.swing.JComboBox<>(modelcomboboxDD);
        JLB_BL_DD = new javax.swing.JLabel();
        loaddulieuvaocomboboxNN();
        JCBB_BLHT_NN = new javax.swing.JComboBox<>(modelcomboboxNN);
        JLB_BL_NN = new javax.swing.JLabel();
        jCheckBoxLuongLien = new javax.swing.JCheckBox();
        jCheckBoxPartTime = new javax.swing.JCheckBox();
        jCheckBoxFullTime = new javax.swing.JCheckBox();
        JLB_BL_LUONG = new javax.swing.JLabel();
        loaddulieuvaocomboboxLB();
        JCBB_BLHT_LB = new javax.swing.JComboBox<>(modelcomboboxLB);
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        loaddulieuvaocomboboxLL();
        JCBB_BLHT_LL = new javax.swing.JComboBox<>(modelcomboboxLL);
        Loc = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 153, 0));

        jPanel1.setBackground(new java.awt.Color(2, 89, 205));
        jPanel1.setPreferredSize(new java.awt.Dimension(677, 114));

        jPanel3.setBackground(new java.awt.Color(255, 234, 150));

        jLabel1.setBackground(new java.awt.Color(255, 234, 150));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("QUẢN LÝ CÔNG VIỆC");

        Them.setBackground(new java.awt.Color(255, 234, 150));
        Them.setText("Thêm công việc");
        Them.setPreferredSize(new java.awt.Dimension(75, 30));
        Them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemActionPerformed(evt);
            }
        });

        Sua.setBackground(new java.awt.Color(255, 234, 150));
        Sua.setText("Sửa");
        Sua.setPreferredSize(new java.awt.Dimension(75, 30));
        Sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SuaActionPerformed(evt);
            }
        });

        Xoa.setBackground(new java.awt.Color(255, 234, 150));
        Xoa.setText("Xoá");
        Xoa.setPreferredSize(new java.awt.Dimension(75, 30));
        Xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XoaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(Them, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Xoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Sua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                    .addComponent(Them, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Sua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Xoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(255, 234, 150));

        Timkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TimkiemActionPerformed(evt);
            }
        });
        Timkiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TimkiemKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBackground(jPanel3.getBackground());

        JCBB_BLHT_DD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
					JCBB_BLHT_DDActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

        JLB_BL_DD.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        JLB_BL_DD.setText("Địa điểm");

        JCBB_BLHT_NN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
					JLB_BLHT_NNActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

        JLB_BL_NN.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        JLB_BL_NN.setText("Ngành nghề");

        jCheckBoxLuongLien.setText("Lương liền");
        jCheckBoxLuongLien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	try {
					jCheckBoxLuongLienActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

        jCheckBoxPartTime.setText("PartTime");
        jCheckBoxPartTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	try {
					jCheckBoxPartTimeActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

        jCheckBoxFullTime.setText("FullTime");
        jCheckBoxFullTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
					jCheckBoxFullTimeActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

        JLB_BL_LUONG.setFont(new java.awt.Font("sansserif", 1, 12)); // NOI18N
        JLB_BL_LUONG.setText("Lương");

        JCBB_BLHT_LB.addActionListener(new java.awt.event.ActionListener() {
        	
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
					JCBB_BLHT_LBActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

        jLabel2.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel2.setText(">");

        jLabel3.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel3.setText("<");

        JCBB_BLHT_LL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
					JCBB_BLHT_LLActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

        Loc.setText("Lọc");
        Loc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
					LocActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(JLB_BL_NN)
                            .addComponent(JCBB_BLHT_NN, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(JCBB_BLHT_DD, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jCheckBoxFullTime)
                                .addGap(43, 43, 43)
                                .addComponent(JLB_BL_LUONG))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jCheckBoxPartTime)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(JCBB_BLHT_LB, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jCheckBoxLuongLien)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(JCBB_BLHT_LL, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addComponent(Loc))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(JLB_BL_DD)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(JLB_BL_DD)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JCBB_BLHT_DD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jCheckBoxFullTime))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JLB_BL_NN)
                                    .addComponent(jCheckBoxPartTime))
                                .addGap(4, 4, 4))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JCBB_BLHT_LB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JCBB_BLHT_NN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jCheckBoxLuongLien))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JCBB_BLHT_LL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3)))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(JLB_BL_LUONG)
                        .addGap(9, 9, 9)
                        .addComponent(Loc)))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(2, 89, 205));

        jTable1.setBackground(new java.awt.Color(255, 234, 150));
        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "MACV", "MADT", "TGBDTD", "TGKTTD", "Luong", "DiaDiem", "MOTA", "NGANHNGHE", "LOAICV", "SLTUYEN"
            }
        ));
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTable1.setGridColor(new java.awt.Color(2, 89, 205));
        jTable1.setSelectionBackground(new java.awt.Color(255, 153, 0));
        jTable1.setSelectionForeground(new java.awt.Color(2, 89, 205));
        jTable1.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        jTable1.setShowGrid(true);
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 668, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(189, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 680, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemActionPerformed
          
        glasspanepopup.GlassPanePopup.showPopup(new NewJPanel_popup_CV(1, modeltb)); 
    }//GEN-LAST:event_ThemActionPerformed

    private void XoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XoaActionPerformed
        // TODO add your handling code here:
        int [] selectrows = jTable1.getSelectedRows();
        String sql, ma;
        sql = "DELETE FROM CONGVIEC WHERE MACV = ?"; 
		PreparedStatement stm;  
        try {
            stm = connec.prepareStatement(sql);
            for(int i = 0; i < selectrows.length; i++)
    	{
        	ma = (String) jTable1.getValueAt(selectrows[0], 0);
        	stm.setString(1, ma);
        	stm.executeUpdate();
    		modeltb.removeRow(selectrows[0]);
    	}
        } catch (SQLException ex) {
            Logger.getLogger(QLCV.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Công việc này đã có người apply đi làm, không thể xóa!", "Thông báo", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_XoaActionPerformed

    private void SuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SuaActionPerformed

    	row_n = jTable1.getSelectedRow(); 
        NewJPanel_popup_CV a = new NewJPanel_popup_CV(row_n, jTable1, 2, modeltb); 
        glasspanepopup.GlassPanePopup.showPopup(a);
    }//GEN-LAST:event_SuaActionPerformed

    private void TimkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TimkiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TimkiemActionPerformed

    private void TimkiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TimkiemKeyReleased
        // TODO add your handling code here:
        float so = 0;  
    	arls.clear();
    	try { 
	       	 if(this.Timkiem.getText() != null) so = 0;
	       	 else if(this.Timkiem.getText().chars().allMatch(Character::isDigit)) so = Float.parseFloat(this.Timkiem.getText());
	       	 String sqlsearch = "SELECT * FROM CONGVIEC WHERE LOWER(MACV) LIKE '%" + this.Timkiem.getText() +  "%' OR LOWER(MADT)  LIKE '%" + this.Timkiem.getText() + "%' OR LOWER(TGBDTD)  LIKE '%" + this.Timkiem.getText() +  "%' OR TGKTTD LIKE '%" + this.Timkiem.getText() +  "%' OR LUONG LIKE  '%" + this.Timkiem.getText()  +  "%' OR DIADIEM LIKE  '%" + this.Timkiem.getText() +  "%' OR MOTA LIKE  '%" + this.Timkiem.getText() +  "%' OR NGANHNGHE LIKE  '%" + this.Timkiem.getText() +  "%' OR LOAICV LIKE  '%" + this.Timkiem.getText() +  "%' OR SLCANTUYEN LIKE  '%" + this.Timkiem.getText() +  "%'";
	       	 Statement stm = connec.createStatement();
	       	 ResultSet rs = stm.executeQuery(sqlsearch); 
	       	 
	       	 loaddulieuvao_arrlist(rs);
	       	 hienthiDLrabang();
	       } 
	       catch(SQLException e){
	           e.printStackTrace();
       }
    }//GEN-LAST:event_TimkiemKeyReleased

    private void JCBB_BLHT_DDActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {//GEN-FIRST:event_JCBB_BLHT_DDActionPerformed
    	String diadiem = (String) JCBB_BLHT_DD.getSelectedItem();
    	 
    		String sqlsearch = "SELECT * FROM CONGVIEC WHERE DIADIEM = '"+ diadiem +"'"; 
	    	Statement stm = connec.createStatement();
	    	ResultSet rss = stm.executeQuery(sqlsearch);
	    	arls.clear();
	    	loaddulieuvao_arrlist(rss);
	    	hienthiDLrabang();  
    	
    }//GEN-LAST:event_JCBB_BLHT_DDActionPerformed

    private void jCheckBoxFullTimeActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {//GEN-FIRST:event_jCheckBoxFullTimeActionPerformed

    	 
	    	jcb_text = "FullTime";
	    	String sqlsearch = "SELECT * FROM CONGVIEC WHERE LOAICV = '"+ jcb_text +"'";
	
	    	Statement stm = connec.createStatement();
	    	ResultSet rss = stm.executeQuery(sqlsearch);
	    	arls.clear();
	    	loaddulieuvao_arrlist(rss);
	    	hienthiDLrabang(); 
    }//GEN-LAST:event_jCheckBoxFullTimeActionPerformed
    
    private void jCheckBoxPartTimeActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {//GEN-FIRST:event_jCheckBoxFullTimeActionPerformed
    	jcb_text = "PartTime";
    	String sqlsearch = "SELECT * FROM CONGVIEC WHERE LOAICV = '"+ jcb_text +"'";

    	Statement stm = connec.createStatement();
    	ResultSet rss = stm.executeQuery(sqlsearch);
    	arls.clear();
    	loaddulieuvao_arrlist(rss);
    	hienthiDLrabang();
    }//GEN-LAST:event_jCheckBoxFullTimeActionPerformed
    
    private void jCheckBoxLuongLienActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {//GEN-FIRST:event_jCheckBoxFullTimeActionPerformed
    	jcb_text = "Lương liền";
    	String sqlsearch = "SELECT * FROM CONGVIEC WHERE LOAICV = '"+ jcb_text +"'";

    	Statement stm = connec.createStatement();
    	ResultSet rss = stm.executeQuery(sqlsearch);
    	arls.clear();
    	loaddulieuvao_arrlist(rss);
    	hienthiDLrabang();
    }//GEN-LAST:event_jCheckBoxFullTimeActionPerformed

    private void JLB_BLHT_NNActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {//GEN-FIRST:event_JLB_BLHT_NNActionPerformed
    	String nganhnghe = (String) JCBB_BLHT_NN.getSelectedItem();
    	String sqlsearch = "SELECT * FROM CONGVIEC WHERE NGANHNGHE = '"+ nganhnghe +"'";

    	Statement stm = connec.createStatement();
    	ResultSet rss = stm.executeQuery(sqlsearch);
    	arls.clear();
    	loaddulieuvao_arrlist(rss);
    	hienthiDLrabang();
    }//GEN-LAST:event_JLB_BLHT_NNActionPerformed

    private void JCBB_BLHT_LBActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {//GEN-FIRST:event_JCBB_BLHT_LBActionPerformed
    	
    }//GEN-LAST:event_JCBB_BLHT_LBActionPerformed
    
    
    
    private void JCBB_BLHT_LLActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {//GEN-FIRST:event_JCBB_BLHT_LLActionPerformed
    	
    }//GEN-LAST:event_JCBB_BLHT_LLActionPerformed

    private JCheckBox getSelectedCheckBox(ButtonGroup buttonGroup) {
        for (Enumeration<AbstractButton> buttons = buttonGroup.getElements(); buttons.hasMoreElements();) {
            JCheckBox checkBox = (JCheckBox) buttons.nextElement();
            if (checkBox.isSelected()) {
                return checkBox;
            }
        }
        return null;
    }
    private void LocActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {//GEN-FIRST:event_LocActionPerformed
    	String nganhnghe = (String) JCBB_BLHT_NN.getSelectedItem();
    	String diadiem = (String) JCBB_BLHT_DD.getSelectedItem();
    	String luongbe = (String) JCBB_BLHT_LB.getSelectedItem();
    	String luonglon = (String) JCBB_BLHT_LL.getSelectedItem();
    	
    	JCheckBox selectedCheckBox = getSelectedCheckBox(buttonGroup1); 
        String text = null;
        if (selectedCheckBox != null) {
        	text = selectedCheckBox.getText(); 
        } 
        String sqlsearch;
        if (selectedCheckBox != null)
        	sqlsearch = "SELECT * FROM CONGVIEC WHERE NGANHNGHE = '"+ nganhnghe +"' AND DIADIEM = '" + diadiem + "' AND LOAICV = '" + text + "' AND LUONG > " + luongbe + " AND LUONG < "+ luonglon ;
        else 
        	sqlsearch = "SELECT * FROM CONGVIEC WHERE NGANHNGHE = '"+ nganhnghe +"' AND DIADIEM = '" + diadiem + "'  AND LUONG > " + luongbe + " AND LUONG < "+ luonglon  ;


    	Statement stm = connec.createStatement();
    	ResultSet rss = stm.executeQuery(sqlsearch);
    	arls.clear();
    	loaddulieuvao_arrlist(rss);
    	hienthiDLrabang();
    }//GEN-LAST:event_LocActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> JCBB_BLHT_DD;
    private javax.swing.JComboBox<String> JCBB_BLHT_NN; 
    private javax.swing.JComboBox<String> JCBB_BLHT_LB;// lương từ - lương bé nhất
    private javax.swing.JComboBox<String> JCBB_BLHT_LL;// lương đến - lương lớn nhất
    private javax.swing.JLabel JLB_BL_DD;
    private javax.swing.JLabel JLB_BL_LUONG;
    private javax.swing.JLabel JLB_BL_NN;
    private javax.swing.JButton Loc;
    private javax.swing.JButton Sua;
    private javax.swing.JButton Them;
    private javax.swing.JTextField Timkiem;
    private javax.swing.JButton Xoa;
    private javax.swing.ButtonGroup buttonGroup1; 
    private javax.swing.JCheckBox jCheckBoxFullTime;
    private javax.swing.JCheckBox jCheckBoxPartTime;
    private javax.swing.JCheckBox jCheckBoxLuongLien;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
