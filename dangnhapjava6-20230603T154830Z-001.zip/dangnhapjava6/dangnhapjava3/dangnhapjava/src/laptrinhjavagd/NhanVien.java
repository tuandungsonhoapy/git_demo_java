/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laptrinhjavagd;

/**
 *
 * @author Le Anh Tuan Dung
 */
public class NhanVien {
    private String MANV;
    private String TENNV;
    private String NgaySinh;
    private double Luong;
    private String SDT;
    private String NGAYVL;

    public NhanVien() {
    }

    public NhanVien(String MANV, String TENNV, String NgaySinh, double Luong, String SDT, String NGAYVL) {
        this.MANV = MANV;
        this.TENNV = TENNV;
        this.NgaySinh = NgaySinh;
        this.Luong = Luong;
        this.SDT = SDT;
        this.NGAYVL = NGAYVL;
    }

    public String getMANV() {
        return MANV;
    }

    public void setMANV(String MANV) {
        this.MANV = MANV;
    }

    public String getTENNV() {
        return TENNV;
    }

    public void setTENNV(String TENNV) {
        this.TENNV = TENNV;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String NgaySinh) {
        this.NgaySinh = NgaySinh;
    }

    public double getLuong() {
        return Luong;
    }

    public void setLuong(double Luong) {
        this.Luong = Luong;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public String getNGAYVL() {
        return NGAYVL;
    }

    public void setNGAYVL(String NGAYVL) {
        this.NGAYVL = NGAYVL;
    }
    
    
}
