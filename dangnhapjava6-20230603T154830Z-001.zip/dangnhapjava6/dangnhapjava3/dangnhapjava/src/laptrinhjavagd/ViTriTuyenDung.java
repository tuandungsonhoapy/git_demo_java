/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laptrinhjavagd;

/**
 *
 * @author Le Anh Tuan Dung
 */
public class ViTriTuyenDung {
    private String MACV;
    private String MAKH;
    private String MANV;
    private String TGTD;

    public ViTriTuyenDung() {
    }

    public ViTriTuyenDung(String MACV, String MAKH, String MANV, String TGTD) {
        this.MACV = MACV;
        this.MAKH = MAKH;
        this.MANV = MANV;
        this.TGTD = TGTD;
    }

    public String getMACV() {
        return MACV;
    }

    public void setMACV(String MACV) {
        this.MACV = MACV;
    }

    public String getMAKH() {
        return MAKH;
    }

    public void setMAKH(String MAKH) {
        this.MAKH = MAKH;
    }

    public String getMANV() {
        return MANV;
    }

    public void setMANV(String MANV) {
        this.MANV = MANV;
    }

    public String getTGTD() {
        return TGTD;
    }

    public void setTGTD(String TGTD) {
        this.TGTD = TGTD;
    }
    
    
}
