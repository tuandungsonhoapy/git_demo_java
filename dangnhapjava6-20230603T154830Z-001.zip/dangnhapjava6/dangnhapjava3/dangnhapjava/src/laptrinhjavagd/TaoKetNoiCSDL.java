/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laptrinhjavagd;

import java.sql.Connection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author dosid
 */
public class TaoKetNoiCSDL { 
	private Connection connec; 
	private static String mysqldriver = "com.mysql.jdbc.Driver";
	private static String localhost_port = "jdbc:mysql://localhost:3306/nho?useSSL=false&serverTimezone=UTC";
	private static String user = "nho";
	private static String password = "4444";
	
    public Connection TKNCSDL()
    { 
        try {
            Class.forName(mysqldriver);
            connec = DriverManager.getConnection(localhost_port, user, password);
        } catch (ClassNotFoundException e) { 
            Logger.getLogger(TaoKetNoiCSDL.class.getName()).log(Level.SEVERE, null, e);
            return null;
        }
        catch(SQLException e){
            Logger.getLogger(TaoKetNoiCSDL.class.getName()).log(Level.SEVERE, null, e);
            return null;
        } 
	        return connec;
    }
    
    
}
