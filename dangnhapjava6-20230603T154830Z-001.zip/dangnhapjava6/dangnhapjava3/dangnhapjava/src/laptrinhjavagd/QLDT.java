/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package laptrinhjavagd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import static java.time.temporal.TemporalQueries.localDate;
import java.util.Date;

import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Le Anh Tuan Dung
 */
public class QLDT extends javax.swing.JFrame {
    private Main manager;
    private Main_NV manager_NV;
 
    /**
     * Creates new form QLDT
     */
    public QLDT(Main m) {
        initComponents();       
        this.manager = m;
        this.setLocationRelativeTo(null);
        edit_components();
        edit_color();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
    }
    
    public QLDT(Main_NV m) {
        initComponents();       
        this.manager_NV = m;
        this.setLocationRelativeTo(null);
        edit_components();
        edit_color();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
    }
    
    
    public QLDT() {
        initComponents();       
        this.setLocationRelativeTo(null);
        edit_components();
        edit_color();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
        insert_DT_update();
    }
    
    public Main get_frame_manager()
    {
        return this.manager;
    }
    
    
    
    public void edit_components()
    {
        this.jButton1.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        this.jButton2.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        //this.jButton3.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        this.jButton4.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        this.jTextField1.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        this.jPanel1.setBorder(new Setborder(new java.awt.Color(182, 76, 11), 0, 20, 10, 2));
        //this.jScrollPane1.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        
        this.jPanel1.setLayout(new GridLayout(0,3,25,25));
        
        this.jScrollPane1.setBackground(new java.awt.Color(2, 89, 205));
    }
    
    public void edit_color()
    {
        this.getContentPane().setBackground(new java.awt.Color(2, 89, 205));
        this.jPanel1.setBackground(new java.awt.Color(255, 234, 150));
        this.setBackground(new java.awt.Color(2, 89, 205));
        this.jButton1.setBackground(new java.awt.Color(255, 234, 150));
        this.jButton2.setBackground(new java.awt.Color(255, 234, 150));
        //this.jButton3.setBackground(new java.awt.Color(255, 234, 150));
        this.jButton4.setBackground(new java.awt.Color(255, 234, 150));
        this.jButton1.setForeground(new java.awt.Color(182, 76, 11));
        this.jButton2.setForeground(new java.awt.Color(182, 76, 11));
        //this.jButton3.setForeground(new java.awt.Color(182, 76, 11));
        this.jButton4.setForeground(new java.awt.Color(182, 76, 11));
        this.jLabel1.setForeground(new java.awt.Color(255, 234, 150));

    }
    
    public TTDT insert_DT()
    {
         
        Font font = new Font("Times New Roman", Font.BOLD, 16);
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(2,1));
        JPanel p1 = new JPanel();
        p1.setBackground(new java.awt.Color(2, 89, 205));
        p1.setLayout(new GridLayout(2,1));
        JButton b = new JButton("Thông tin đối tác");
        b.setForeground(new java.awt.Color(182, 76, 11));
        b.setBackground(new java.awt.Color(255, 234, 150));
        TTDT info = new TTDT(this);
        b.setBorder(new Setborder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonbActionPerformed(evt);
                //jButtonb2ActionPerformed(evt);
            }

            private void jButtonbActionPerformed(ActionEvent evt) {
                manager.edit_window(info);
            }
        });
        
        b.setFont(font);
        JButton b1 = new JButton("Tra cứu công việc");
        b1.setForeground(new java.awt.Color(182, 76, 11));
        b1.setBackground(new java.awt.Color(255, 234, 150));
        TCCV ttcv = new TCCV(this);
        b1.setBorder(new ThreeDimensionalBorder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonb1ActionPerformed(evt);
                //jButtonb2ActionPerformed(evt);
            }

            private void jButtonb1ActionPerformed(ActionEvent evt) {
                manager.edit_window(ttcv);
            }
        });
        b1.setFont(font);
        p1.add(b);
        p1.add(b1);
        p.setPreferredSize(new Dimension(160,180));
        JPanel p2 = new JPanel();        
        p2.setBackground(new java.awt.Color(255, 51, 255));
        p2.setBorder(new Setborder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        p.add(p2);
        p.add(p1);
        p.setBackground(new java.awt.Color(2, 89, 205));
        this.jPanel1.add(p);
        
        return info;
    }
    
    public TTDT insert_DT_update()
    {
         
        Font font = new Font("Times New Roman", Font.BOLD, 16);
        JPanel p = new JPanel();
        p.setLayout(new BorderLayout());
        JPanel p1 = new JPanel();
        p1.setBackground(new java.awt.Color(2, 89, 205));
        p1.setLayout(new GridLayout(1,1));
        JButton b = new JButton("Thông tin đối tác");
        b.setForeground(new java.awt.Color(182, 76, 11));
        b.setBackground(new java.awt.Color(255, 234, 150));
        TTDT info = new TTDT(this);
        b.setBorder(new Setborder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonbActionPerformed(evt);
                //jButtonb2ActionPerformed(evt);
            }

            private void jButtonbActionPerformed(ActionEvent evt) {
                manager.edit_window(info);
            }
        });
        
        b.setFont(font);
        p1.add(b);
        p.setPreferredSize(new Dimension(160,180));
        JPanel p2 = new JPanel();        
        p2.setBackground(new java.awt.Color(255, 51, 255));
        p2.setBorder(new Setborder(new java.awt.Color(182, 76, 11), 0, 0, 10, 2));
        p.add(p2, BorderLayout.CENTER);
        p.add(p1, BorderLayout.SOUTH);
        p.setBackground(new java.awt.Color(2, 89, 205));
        this.jPanel1.add(p);
        
        return info;
    }
    
   // private void jButtonb2ActionPerformed(ActionEvent evt) {
   //             this.setVisible(false);
    //        }
  

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(2, 89, 205));
        setLocation(new java.awt.Point(0, 0));
        setLocationByPlatform(true);
        setPreferredSize(new java.awt.Dimension(604, 540));
        setSize(new java.awt.Dimension(604, 600));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel1.setText("Quản Lý Đối Tác");

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Thêm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Xóa");

        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setText("Search");

        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 604, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(105, 105, 105)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField1)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        glasspanepopup.GlassPanePopup.showPopup(new NewJPanel_popup_KH());
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLDT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLDT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLDT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLDT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QLDT().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

    private void setBorder(Border border) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
